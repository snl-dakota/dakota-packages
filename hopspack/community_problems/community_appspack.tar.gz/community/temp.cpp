#include <mpi.h>
int main ()
{
  int c; 
  char** v; 
  MPI_Init(&c,&v);;
  return 0;
}
