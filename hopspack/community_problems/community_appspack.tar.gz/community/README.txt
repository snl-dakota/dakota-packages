*** Feb 23, 2005 ***

COMMANDS ON CATALYST
--------------------

To show available nodes:
  
  showmesh

To get 8 nodes in interactive mode:

  qsub -I -l nodes=8

File containing list of nodes:

  $PBS_NODEFILE


GETTING APPSPACK CONFIGURED AND RUNNING WITH LOCAL MPICH
--------------------------------------------------------

To configure APPSPACK with local MPICH:

  cd appspack-mpich
  ../appspack/configure --with-mpi-compilers=/home/tgkolda/mpich/bin --with-cxxflags="-DAPPSPACK_MPI_TIMING"

To run using MPI:

  /home/tgkolda/mpich/bin/mpirun -machinefile $PBS_NODEFILE -np <nnodes> 

For example, 

  cd appspack-mpich/examples
  /home/tgkolda/mpich/bin/mpirun -machinefile $PBS_NODEFILE -np 8 ../src/appspack_mpi example1.apps


GETTING APPSPACK CONFIGURED AND RUNNING WITH SYSTEM LAMPI
---------------------------------------------------------

To configure APPSPACK with local MPICH:

  cd appspack-lampi
  ../appspack/configure --with-mpi=/apps/x86/mpi/lampi/gcc-3.2.3-42/lampi-1.5.10 --with-cxxflags="-DAPPSPACK_MPI_TIMING"

To run using MPI:

  /apps/x86/mpi/lampi/gcc-3.2.3-42/lampi-1.5.10/bin/mpirun -machinefile $PBS_NODEFILE -np <nnodes> 

For example, 

  cd appspack/examples
  /home/tgkolda/mpich/bin/mpirun -machinefile $PBS_NODEFILE -np 8 ../src/appspack_mpi example1.apps


GETTING COMMUNITY PROBLEMS RUNNING
----------------------------------

Copy my apps-modflow directory into your directory.

     cd ~
     cp -r /home/tgkolda/Community-Problems/apps-modflow .

There are 5 problems:

UNC5
UNC6
CON5
CON6
HC

Each problem has three files associated with it:

<prob>.apps - needs to be edited
APPScom<PROB> - needs to be edited
eval<PROB>

You need to edit two of the three files to replace tgkolda with
dpdiach.

To run the problem, do the following:

   /usr/local/lampi/bin/mpirun -n <#processes> -H <node #s> \
   ~/appspack/src/appspack_mpi <prob>.apps


