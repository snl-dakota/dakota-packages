#!/bin/sh
for j in apps pps
do
for i in `seq 1 1`;
do
        echo $j.$i
done 
done

